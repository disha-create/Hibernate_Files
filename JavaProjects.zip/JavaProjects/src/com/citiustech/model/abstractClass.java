package com.citiustech.model;

import java.util.concurrent.SynchronousQueue;

public abstract class abstractClass {
	
	public int a =6;
	public int b= 10;
	
	abstract public void greet();
	
	public void addNumbers(){
		System.out.println(a+b);
	}
	
	 abstract public void greet2();
}
