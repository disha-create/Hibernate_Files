package com.citiustech.model;

class multiThread1 implements Runnable{
	
	public void run(){
		System.out.println("Thread1 running");
	}
	
}

class multiThread2 implements Runnable{
	
	public void run(){
		System.out.println("Thread2 running");
	}
	
}

public class ThreadConstructrWithRunnableInterface {
	
	public static void main(String[] args){
		
		multiThread1 mt1 = new multiThread1();
		Thread T1 = new Thread(mt1,"Disha");
		
		System.out.println(T1.getId());
		System.out.println(T1.getName());
		
		
		Runnable mt2 = new multiThread2();
		Thread T2 = new Thread(mt2,"Misal");
		
		System.out.println(T2.getId());
		System.out.println(T2.getName());
		
	}

}
