package com.citiustech.model;


//Creating thread by extending Thread class

//class thread1 extends Thread{
//	
//	public void run(){
//		System.out.println("Thread1 running...");
//	}
//}
//public class MyThread {
//	
//	public static void main(String[] args){
//		
//		
//		thread1 t1 = new thread1();
//		Thread T = new Thread();
//		
//		t1.start();
//		
//	}
//
//}


//Creating thread by implementing runnable interface
class thread1 implements Runnable{
	public void run(){
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
		System.out.println("thread1 running");
	}
}

class thread2 implements Runnable{
	public void run(){
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
		System.out.println("thread2 running...");
	}
}


public class MyThread {

	public static void main(String[] args){
		
		thread1 t1 = new thread1();
		Thread T = new Thread(t1);
		
		
		thread2 t2 = new thread2();
		Thread T1 = new Thread(t2);
		
		T.start();
		T1.start();
		
		
	}
}