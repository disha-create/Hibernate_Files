package com.citiustech.model;


class MultiTread1 extends Thread{
	
	public void run(String s){
		int i = 0;
		while(i<1000){
		System.out.println("Thread1 running...."+s);
		i++;
	}
	}
	
}



class MultiTread2 extends Thread{
	
	public void run(String st){
		int i = 0;
		while(i<1000){
		System.out.println("Thread2 running...."+ st);
		i++;
	}
	}
	
}

public class ThreadConstructorWithExtendingThread {
	
	public static void main(String[] args){
		
		Thread T1 = new Thread("ThreadName1");
		T1.start();
		
		Thread T2 = new Thread("ThreadName2");
		T2.start();
		
		MultiTread1 m1 = new MultiTread1();
		
		System.out.println(T1.getId());
		System.out.println(T1.getName());
		
		System.out.println(T2.getId());
		System.out.println(T2.getName());
		
	}

}
