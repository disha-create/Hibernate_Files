package com.citiustech.model;

public class SmartTelephone extends Telephone implements GPS,Camera {
	
	public void ring(){
		System.out.println("Ringing...");
	}
	
	public void lift(){
		System.out.println("Lifting...");
	}
	public void disconnect(){
		System.out.println("Disconnecting...");
		
		
	}

	public void Findlocation(){
		System.out.println("Finding location...");
	}
	public void ShowLocation(){
		System.out.println("Here");
	}
	
	public void TakeSnap(){
		System.out.println("Smile");
	}
	public void RecordVideo(){
		System.out.println("Action");
	}
}
