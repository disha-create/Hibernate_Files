package com.citiutech.test;

import com.citiutech.bank.Account;
import com.citiutech.bank.CurrentAccount;
import com.citiutech.bank.Profitable;
import com.citiutech.bank.SavingsAccount;

public class BankTest2 {
	
	/*
	 * private static void payAnnualInterest(Account[] accounts) { for (Account
	 * account : accounts) { if(account instanceof SavingsAccount) { SavingsAccount
	 * sacc = (SavingsAccount) account; sacc.addInterest(1); } } }
	 */
	
	private static void payAnnualInterest(Account[] accounts) {
		for (Account account : accounts) {
			if(account instanceof Profitable) {
				Profitable p = (Profitable) account;
				p.addInterest(1);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account[] accounts = new Account[4];
		accounts[0] = new SavingsAccount();
		accounts[0].deposit(10000);
		accounts[1] = new CurrentAccount();
		accounts[1].deposit(10000);
		accounts[2] = new CurrentAccount();
		accounts[2].deposit(20000);
		accounts[3] = new SavingsAccount();
		accounts[3].deposit(20000);
		
		for (Account account : accounts) {
			System.out.printf("Balance = %.2f%n", account.getBalance());
		}
		
		System.out.println("Pay Annual Interest");
		payAnnualInterest(accounts);
		for (Account account : accounts) {
			System.out.printf("Balance = %.2f%n", account.getBalance());
		}
	}

}


