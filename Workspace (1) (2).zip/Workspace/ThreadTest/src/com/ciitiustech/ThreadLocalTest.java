package com.ciitiustech;

public class ThreadLocalTest {
	
	//static String client;
	static ThreadLocal<String> client = new ThreadLocal<String>();
	
	private static void handleJob(int job) {
		System.out.printf("Thread<%d> has accepted job with id %d for client %s%n", Thread.currentThread().hashCode(), job, client.get());
		Worker.doWork(10 + job);
		System.out.printf("Thread<%d> has finished job with id %d for client %s%n", Thread.currentThread().hashCode(), job, client.get());
	}

	public static void main(String[] args) {
		Thread child = new Thread(() ->  {
			client.set("Jack"); 
			handleJob(5);
		});
		child.start();
		client.set("Jill");;
		handleJob(7);
	}
}




