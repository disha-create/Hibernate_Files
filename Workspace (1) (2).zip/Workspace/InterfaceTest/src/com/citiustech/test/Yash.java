package com.citiustech.test;

import com.citiustech.Filter;

public class Yash implements Filter {
	
	public boolean allowed(int value) {
		return value % 2 == 1;
	}
}
