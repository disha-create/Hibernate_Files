package com.citiustech;

@FunctionalInterface
public interface Filter {
	boolean allowed(int value);
}
