package com.citiustech;

public class Algorithm {

	public static void printAll(int[] numbers) {
		for (int value : numbers) {
			System.out.printf("%d ", value);
		}
		System.out.println();
	}
	
	/*
	 * public static void printOdd(int[] numbers) { for (int value : numbers) {
	 * if(value % 2 == 1) System.out.printf("%d ", value); } System.out.println(); }
	 */
	
	public static void printIf(int[] numbers, Filter check) {
		for (int value : numbers) {
			if(check.allowed(value))
				System.out.printf("%d ", value);
		}
		System.out.println();
	}
}


