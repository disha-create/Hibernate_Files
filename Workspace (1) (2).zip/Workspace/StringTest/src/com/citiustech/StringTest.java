package com.citiustech;

//StringBuffer or StringBuilder
//String in Java is immutable
public class StringTest {
	public static void main(String[] args) {
		String s1 = "Akash"; //2000 -> Akash
		System.out.println(s1);
		String s2 = new String("Akash"); //String s2 = s1;	// 2000 -> Akash
		System.out.println(s2);		//Interning
		/*
		 * if(s1 == s2) { System.out.println("Equal"); }else {
		 * System.out.println("Not Equal"); }
		 */
		if(s1.equals(s2)) {
			System.out.println("Equal");
		}else {
			System.out.println("Not Equal");
		}
		StringBuffer strBuf = new StringBuffer("Akash");
		System.out.println(strBuf.append("Thakur"));
		
		StringBuilder strBuild = new StringBuilder("Akash");
		System.out.println(strBuild.append("Thakur"));
	}
}




