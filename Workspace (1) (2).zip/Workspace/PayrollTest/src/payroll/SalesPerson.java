package payroll;

public class SalesPerson extends Employee{

	private double sales;
	
	public SalesPerson() {
		// TODO Auto-generated constructor stub
		this(90, 75, 50000);
	}
	
	public SalesPerson(int hours, float rate, double sales) {
		// TODO Auto-generated constructor stub
		super(hours, rate);		
		this.sales = sales;
		System.out.println("SalesPerson instantiated");
	}

	public double getSales() {
		return sales;
	}

	public void setSales(double sales) {
		this.sales = sales;
	}
	
	public double getNetIncome() {
		double income = super.getNetIncome();
		income += (sales / 10);
		return income;
	}
}
