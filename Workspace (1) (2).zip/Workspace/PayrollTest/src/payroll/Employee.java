package payroll;

public class Employee {

	private int hours;
	private float rate;
	
	public Employee() {
		// TODO Auto-generated constructor stub
		this(90, 75);
		
	}

	public Employee(int hours, float rate) {
		this.hours = hours;
		this.rate = rate;
		System.out.println("Employee instantiated");
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public float getRate() {
		return rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}
	
	public double getNetIncome() {
		double income = hours * rate;
		int ot = hours - 180;
		
		if(ot > 0) income += 50 * ot;
		
		return income;
	}
}





