package test;

import payroll.Employee;
import payroll.SalesPerson;

public class PayrollTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee jack = new Employee(200, 100);
		//System.out.println("Welcome User");
		//System.out.println("Income of jack = " + jack.getNetIncome());
		System.out.printf("Income of jack = %.2f%n", jack.getNetIncome());
		SalesPerson jill = new SalesPerson(200, 100, 100000);
		System.out.printf("Income of jill = %.2f%n", jill.getNetIncome());
	}

}
