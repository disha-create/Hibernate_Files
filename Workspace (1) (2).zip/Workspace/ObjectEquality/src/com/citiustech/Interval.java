package com.citiustech;

public class Interval {
	private int minutes;
	private int seconds;
	
	
	public Interval(int minutes, int seconds) {
		this.minutes = minutes + seconds / 60;
		this.seconds = seconds % 60;
	}
	
	public int time() {
		return minutes * 60;
	}
	
	public void print() {
		System.out.println(minutes + ":" + seconds);
	}
	
	
	  @Override 
	  public int hashCode() { 
		  // TODO Auto-generated method stub 
		  return 1234; 
	  }
	 
	
	@Override
	public boolean equals(Object other) {
		if(other instanceof Interval) {
			Interval obj = (Interval) other;
			return (this.minutes == obj.minutes) && (this.seconds == obj.seconds);
		}
		return false;
	}
	
	@Override
	public String toString() {
		return String.format("%dm:%ds", minutes, seconds);
	}
}








