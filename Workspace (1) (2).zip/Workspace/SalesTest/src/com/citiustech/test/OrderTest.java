package com.citiustech.test;

import com.citiustech.sales.Customer;

public class OrderTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Customer customer = new Customer();
			int orderNo = customer.placeOrder("CU302", 302, 25);
			System.out.printf("New order number : %d%n", orderNo);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Order Failed :" + e.getMessage());
		}
	}

}
