package com.citiustech.sales;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.Statement;
import java.sql.Types;

public class Customer {

	/*
	 * public int placeOrder(String customerId, int productNo, int quantity) throws
	 * SQLException{ Connection con = null; try{ con = DB.connect();
	 * con.setAutoCommit(false); Date today = new Date(System.currentTimeMillis());
	 * Statement stmt = con.createStatement(); // ctr_name | cur_val stmt.
	 * executeUpdate("UPDATE counters SET cur_val=cur_val+1 WHERE ctr_name='orders'"
	 * ); ResultSet rs =
	 * stmt.executeQuery("SELECT cur_val+1000 FROM counters WHERE ctr_name='orders'"
	 * ); rs.next(); int orderNo = rs.getInt(1); rs.close(); stmt.close();
	 * 
	 * PreparedStatement pstmt =
	 * con.prepareStatement("INSERT INTO orders VALUES(?,?,?,?,?)"); pstmt.setInt(1,
	 * orderNo); pstmt.setDate(2, today); pstmt.setString(3, customerId);
	 * pstmt.setInt(4, productNo); pstmt.setInt(5, quantity);
	 * 
	 * pstmt.executeUpdate(); pstmt.close(); con.commit(); con.close(); return
	 * orderNo; }catch (Exception e) { // TODO: handle exception con.rollback();
	 * throw new RuntimeException(e); } }
	 */
	
	public int placeOrder(String customerId, int productNo, int quantity) {
		try {
			Connection con = DB.connect();
			CallableStatement cstmt = con.prepareCall("{call place_order(?,?,?,?)}");
			cstmt.setString(1, customerId);
			cstmt.setInt(2, productNo);
			cstmt.setInt(3, quantity);
			cstmt.registerOutParameter(4, Types.INTEGER);
			cstmt.execute();
			int orderNo = cstmt.getInt(4);
			return orderNo;
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public int placeOrder(String customerId, int productNo, int quantity) {
		try {
			Counter  ctr = DAL.getCounter('order');
			int orderNo = ctr.getNextValue() + 1000;
			OrderDetails order = new OrderDetails();
			order.setCustomerId(customerId);
			order.setProductNo(productNo);
			order.setQuanity(quantity);
			
			d.save(order);
			return orderNo;
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
	}
}


9820580568







