package com.citiustech;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapTest {
	
	//Nested class
	static class IntervalComparator implements Comparator<Interval>{

		@Override
		public int compare(Interval o1, Interval o2) {
			// TODO Auto-generated method stub
			return o1.getSeconds() - o2.getSeconds();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, Interval> store = new TreeMap<String, Interval>(); 
		store.put("Monday", new Interval(4, 7));
		store.put("Tuesday", new Interval(6, 2));
		store.put("Wednesday", new Interval(8, 5));
		store.put("Thursday", new Interval(2, 4));
		store.put("Friday", new Interval(9, 1));
		
		for (Map.Entry<String, Interval> entries :  store.entrySet()) {
			System.out.println(entries.getKey() + "->" + entries.getValue());
			
		}
		System.out.println("Value at Wednesday is = " + store.get("Wednesday"));
	}

}
