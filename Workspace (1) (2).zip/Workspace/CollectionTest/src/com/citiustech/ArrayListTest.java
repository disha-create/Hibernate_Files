package com.citiustech;

import java.util.List;
import java.util.ArrayList;

public class ArrayListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ArrayList<Interval> store = new ArrayList<>();
		List<Interval> store = new ArrayList<Interval>();

		store.add(new Interval(4, 7));
		store.add(new Interval(6, 2));
		store.add(new Interval(8, 5));
		store.add(new Interval(2, 4));
		store.add(new Interval(9, 1));
		//store.add(new Interval(9, 1));
		
		for (Interval interval : store) {
			System.out.println(interval);
		}
		System.out.printf("Indexed value = %s%n", store.get(1));
	}

}
