package com.citiustech;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class HashSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Interval> store = new HashSet<Interval>();

		store.add(new Interval(4, 7));
		store.add(new Interval(6, 2));
		store.add(new Interval(8, 5));
		store.add(new Interval(2, 4));
		store.add(new Interval(9, 1));
		store.add(new Interval(9, 1));
		
		for (Interval interval : store) {
			System.out.println(interval);
		}
		//System.out.printf("Indexed value = %s%n", store.get(1));

	}

}
