package com.citiustech;

class Employee{
	
}

class SimpleStack<V>{
	
	V value;
	
	public SimpleStack(V val) {
		// TODO Auto-generated constructor stub
		value = val;
	}
	
	public V getValue() {
		return value;
	}
}

public class GenMethodTest {
	
	/*
	 * private static int select(int sign, int first, int second) { if(sign > 0)
	 * return first; return second; }
	 * 
	 * private static double select(int sign, double first, double second) { if(sign
	 * > 0) return first; return second; }
	 */
	
	/*
	 * private static Object select(int sign, Object first, Object second) { if(sign
	 * > 0) return first; return second; }
	 */
	
	//Allows to call only java.lang.Object methods
	private static<T> T select(int sign, T first, T second) {
		if(sign > 0) return first;
		return second;
	}
	
	//Bounds 
	private static<T extends Comparable<T>> T max(int sign, T first, T second) {
		if(first.compareTo(second) > 0) return first;
		return second;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SimpleStack<Interval> ssi = new SimpleStack<>(new Interval(4, 5));
		SimpleStack<Employee> sse = new SimpleStack<>(new Employee());
		System.out.println(ssi.getValue());
		int s = -9;
		int a = 10, b = 20;
		//int si = (int) select(s, a, b);
		int si = select(s, a, b);
		System.out.printf("Selected integer = %d%n", si);
		
		double da = 10, db = 20;
		//double sd = (double) select(s, "Monday", db);
		double sd = select(s, da, db);
		//double sd = select(s, da, "dbvar"); // Error
		System.out.printf("Selected double = %.2f%n", sd);
		//Interval i = max(s, new Interval(46, 5), new Interval(7, 8));
		//System.out.printf("Selected Inteval = %s%n", i); // O(1)
	}

}

