package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

class Employee{
	
	public Employee() {
		// TODO Auto-generated constructor stub
		System.out.println("Employee instantiated");
	}
}

class SomeResource implements AutoCloseable{
	String rs = new String("Connection");
	public SomeResource() {
		// TODO Auto-generated constructor stub
		System.out.println("Resource allocated");
	}
	
	public void finalize() {
		for(long  i = 1; i < 999999999; ++i);
		for(int i = 1; i < 999999999; ++i);
		System.out.println("Resource released");
		rs = null;
	}
	
	public void close() {
		if(rs != null)
			System.out.println("Resource released from close method");
	}
}

public class QueryTest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//Employee emp = new Employee();
		/*
		 * Class<?> c = Class.forName("com.citiustech.Employee");
		 * c.getConstructor().newInstance();
		 */
		/*
		 * { SomeResource sr = new SomeResource(); sr.close(); sr = null; //System.gc();
		 * }
		 */
		/*
		 * SomeResource sr = null; try { sr = new SomeResource(); throw new
		 * RuntimeException(); }catch(Exception e){ System.out.println(e.getMessage());
		 * }finally { sr.close(); }
		 */	
		
		/*
		 * try(SomeResource sr = new SomeResource()){ throw new RuntimeException(); }//
		 * sr.close();
		 */		 		
		/*
		 * Class.forName("com.mysql.cj.jdbc.Driver"); Connection con =
		 * DriverManager.getConnection("jdbc:mysql://localhost:3306/sales", "root",
			 * "root"); Statement stmt = con.createStatement(); ResultSet rs =
			 * stmt.executeQuery("SELECT pno, price, stock FROM products");
		 */
		/*
		 * rs.next(); System.out.printf("%d\t%.2f\t%d%n", rs.getInt(1), rs.getDouble(2),
		 * rs.getInt(3)); rs.next(); System.out.printf("%d\t%.2f\t%d%n", rs.getInt(1),
		 * rs.getDouble(2), rs.getInt(3));
		 */
		/*
		 * while(rs.next()) { System.out.printf("%d\t%.2f\t%d%n", rs.getInt(1),
		 * rs.getDouble(2), rs.getInt(3)); } rs.close(); stmt.close(); con.close();
		 */	
		  try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost/sales", "root", "root")){
			try(Statement stmt = con.createStatement()){
				ResultSet rs = stmt.executeQuery("SELECT pno, price, stock FROM products");
				while(rs.next()) {
					System.out.printf("%d\t%.2f\t%d%n", rs.getInt(1),
					rs.getDouble(2), rs.getInt(3)); 
				}// rs.close(); stmt.close(); con.close();
			
			}//stmt.close();
		  }//con.close();
	}

}




