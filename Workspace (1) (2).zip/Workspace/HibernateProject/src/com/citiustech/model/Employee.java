package com.citiustech.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Employee {

	private int empId;
	private int hours;
	private float rate;
	
	public Employee() {
		// TODO Auto-generated constructor stub
		this(0, 70, 90);
	}
	
	public Employee(int empId, int hours, float rate) {
		this.empId = empId;
		this.hours = hours;
		this.rate = rate;
	}

	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	//@Column(name = "emp_id")
	public int getEmpId() {
		return empId;
	}

	
	public void setEmpId(int empId) {
		this.empId = empId;
	}

	@Column(nullable = false)
	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public float getRate() {
		return rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", hours=" + hours + ", rate=" + rate + "]";
	}
	
	private Department department;

	@ManyToOne
	@JoinColumn(name = "deptId")
	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
	
	
}



