package com.citiustech.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.citiustech.model.Account;
//hibernate.cfg.xml

public class AccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction tx = session.beginTransaction();
		
		Account account = new Account();
		account.setId(1004);
		account.setName("Jeff");
		account.setBalance(6000);
		
		session.persist(account);
		
		tx.commit();
		session.close();
		
		System.out.println("Account saved");
	}

}



