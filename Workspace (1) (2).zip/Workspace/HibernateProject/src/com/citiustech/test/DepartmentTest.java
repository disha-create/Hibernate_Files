package com.citiustech.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.model.Department;
import com.citiustech.model.Employee;

public class DepartmentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Department sales = new Department(5001, "Sales");
		
		session.save(sales);
		
		tx.commit();
		session.close();
		
		System.out.println("Department saved");
	}

}
