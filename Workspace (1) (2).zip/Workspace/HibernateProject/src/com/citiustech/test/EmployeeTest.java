package com.citiustech.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.model.Employee;

public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Employee jack = new Employee(101, 180, 100);
		
		session.save(jack);
		
		tx.commit();
		session.close();
		
		System.out.println("Employee saved");
	}

}
