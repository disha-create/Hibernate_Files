package com.citiustech.test;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.citiustech.model.Account;

public class CriteriaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Criteria crt = session.createCriteria(Account.class);
		crt.add(Restrictions.gt("balance", 7000.0));
		
		List<Account> accounts = crt.list();
		
		for (Account account : accounts) {
			System.out.println(account);
		}
		
		session.close();
	}

}
