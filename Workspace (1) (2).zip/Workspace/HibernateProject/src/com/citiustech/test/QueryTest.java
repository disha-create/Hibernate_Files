package com.citiustech.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.citiustech.model.Account;

public class QueryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		//Query query = session.createQuery("FROM Account a");
//		Query query = session.createQuery("SELECT a FROM Account a");
//		List<Account> accounts = query.list();
//		
//		for (Account account : accounts) {
//			System.out.println(account);
//		}
		
		/*
		 * Query query = session.createQuery("SELECT id FROM Account"); List<Integer>
		 * accountId = query.list();
		 * 
		 * for (Integer accId : accountId) { System.out.println(accId); }
		 */
		
		Query query = session.createQuery("SELECT id, name FROM Account WHERE balance BETWEEN 7000 and 8000");
		List<Object[]> accounts = query.list();
		
		for (Object[] values : accounts) {
			System.out.printf("%d\t%s%n", values[0], values[1]);
		}
		
		session.close();
	}

}


