package com.citiustech.model;

public class HibernateUtil {
	
	
	public static Session

}
