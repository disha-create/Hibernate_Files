package com.bob.bank;

//Checked-Exception
public class InsufficientFundsException extends Exception{
}

