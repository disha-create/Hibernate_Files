package com.bob.bank;

//Un-Checked Exception
public class IllegalTransferException extends RuntimeException {
}
