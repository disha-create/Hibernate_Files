package com.bob.bank;

public interface Profitable {

	//float rate = 9.0; //static final field
	void addInterest(int period);
}
