package com.bob.test;
import java.util.*;
import com.bob.bank.Account;
import com.bob.bank.Banker;
import com.bob.bank.Profitable;

public class BobTest {
	private static void payAnnualInterest(Account[] accounts) {
		for (com.bob.bank.Account account : accounts) {
			if(account instanceof Profitable) {
				Profitable p = (Profitable) account;
				p.addInterest(1);
			}
		}
	}
	public static void main(String[] args) {
	int choice;
	String sav,cur;
	Scanner scanner = new Scanner(System.in);
	Map<Account,Integer> acc = new HashMap<Account,Integer>();
    //Creating infinite while loop
    while(true) {
        //Creating menu
    	System.out.println("--------------Welcome to Bank of baroda-------------");
        System.out.println("Press 1 for Open Account");
        System.out.println("Press 2 for Withdraw");
        System.out.println("Press 3 for Deposit");
        System.out.println("Press 4 for Transfer");
        System.out.println("Press 5 for Close Account ");
        System.out.println("Press 6 for Print Account transaction ");
        System.out.println("Press 7 for Quit ");
        System.out.println("------------------------------------------------------");
        //Asking user to make choice
        System.out.println("Make your choice");
        
        choice = scanner.nextInt();
        //Creating switch case branch

    			
    switch (choice) {
    //First case for Open Account
    case 1:
    	System.out.println("-----------------------------------------------------");
    	System.out.println("Press 1 for Saving Account");
    	System.out.println("Press 2 for Current Account");
    	int type = scanner.nextInt();
    	if(type == 1) {
    		Account sa = Banker.openSavingsAccount();
    		System.out.println("-------------------------------------------------");
    		System.out.println("Your SavingAccount is created Sucessfully");
    		System.out.printf("Your AccountNo is:- %d%n",sa.getId());
    		System.out.printf("Your Balance is:- %.2f%n",sa.getBalance());
    		System.out.println("------------------------------------------------------");
    		
    	}
    	else if(type == 2) {
    		Account ca = Banker.openCurrentAccount();
    		System.out.println("-------------------------------------------------");
    		System.out.println("Your CurrentAccount is created Sucessfully");
    		System.out.printf("Your AccountNo is:- %d%n",ca.getId());
    		System.out.printf("Your Balance is:- %.2f%n",ca.getBalance());
    		System.out.println("------------------------------------------------------");
    	
    		
    	}
    	else {
    		System.err.println("Please Enter a Valid Choice");
    	}
    	//System.out.println(type);
    	
      
        break;
    //Second case for finding the difference
    case 2:
    	System.out.println("-----------------------------------------------------");
    	System.err.println("Enter the amount to withdraw");
    	int amount_withdraw = scanner.nextInt();
    	
        
        break;
    //Third case for finding the product
    case 3:
    	System.out.println("-----------------------------------------------------");
    	System.err.println("Enter the amount to deposit");
    	int amount_deposit = scanner.nextInt();
        break;
    //Fourth case for finding the quotient
    case 4:
    	System.out.println("-----------------------------------------------------");
        break;
    //Fifth case to quit the program
    case 5:
    	System.out.println("-----------------------------------------------------");
        
        break;
    case 6:
    	System.out.println("-----------------------------------------------------");
    	
    	break;
    case 7:
        System.exit(0);
    //default case to display the message invalid choice made by the user
    default:
        System.out.println("Invalid choice!!! Please make a valid choice.");
}
    }						
    }
					}
