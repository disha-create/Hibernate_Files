package com.citiustech.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "Transactions")
public class TransactionTable {
	
	public String TransactionID;
	public int accId;
	public String accType;
	public double amount;
	public int custId;
	
	
	public TransactionTable() {
		// TODO Auto-generated constructor stub
	}
	
	

	public TransactionTable(String transactionID, int accId, String accType, double amount, int custId) {
		super();
		this.TransactionID = "TID" + (int)System.currentTimeMillis() % 100000;
		this.accId = accId;
		this.accType = accType;
		this.amount = amount;
		this.custId = custId;
	}


	@Id
	public String getTransactionID() {
		return TransactionID;
	}



	public void setTransactionID(String transactionID) {
		TransactionID = transactionID;
	}



	
	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public double getamount() {
		return amount;
	}

	public void setamount(double amount) {
		this.amount = amount;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}
	
	
	
	

}
