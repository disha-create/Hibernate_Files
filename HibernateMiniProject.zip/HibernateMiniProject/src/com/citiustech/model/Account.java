package com.citiustech.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class Account {
	private int accId;
	private String accType;
	private double balance;
	
	
	public Account() {
		
		// TODO Auto-generated constructor stub
	}

	public Account(int accId, String accType, double balance){
		this.accId = accId;
		this.accType = accType;
		this.balance = balance;
	}

	@Id
	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	@Column(nullable = false, length=20)
	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	private Customer customer;

	@OneToOne
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customers) {
		this.customer = customers;
	}
	
}
