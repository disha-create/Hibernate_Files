package com.citiustech.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.util.HibernateUtil;

public class Banker {
	
	public static void createCustomer(String name, int age, String address, String adharNumber){
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		int custId = (int) System.currentTimeMillis() % 100000;
		
		Customer customer = new Customer(custId, name, age, address, adharNumber);
		session.persist(customer);
		
		tx.commit();
		session.close();
		
		System.out.println("Your Customer Id: "+custId);
		
	}
	
	public static Customer getCustomer(int custID){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Customer c = session.get(Customer.class, custID);
		
		session.close();
		
		return c;		
	}
	
	public static void openSavingAccount(int custId){
		int accId = (int) System.currentTimeMillis() % 10000;
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account account1 = new Account(accId, "Savings", 10000);
		account1.setCustomer(getCustomer(custId));
		session.persist(account1);
		
		tx.commit();
		session.close();
		
		System.out.println("Account Created Successfully.....\n Your Account Id: "+accId);
	}
	
	public static void openCurrentAccount(int custId){
		int accId = (int) System.currentTimeMillis() % 10000;
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account account = new Account(accId, "Current", 0);
		account.setCustomer(getCustomer(custId));
		session.persist(account);
		
		tx.commit();
		session.close();
		
		System.out.println("Account Created Successfully.....\n Your Account Id: "+accId);
	}
	
	public static void Withdraw(int withdrawAccNo, int withdrawAmount){
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		String TransactionID = "TID" + (int)System.currentTimeMillis() % 100000;
		
		Account acc = new Account();
		acc = session.get(Account.class, withdrawAccNo );
		if(acc != null){
	        String acctype = acc.getAccType();
	        double bal = acc.getBalance();
	        if(acctype.compareTo("Savings") == 0){
	        	if(bal >= 10000+withdrawAmount){
	        		System.out.println("Amount deducted from your account with accountId : " + withdrawAccNo);
	        		acc.setBalance(bal-withdrawAmount);
	        		
	        	}
	        }
	        
	        
	        if(acctype.compareTo("Current") == 0){
	        	if(bal >= withdrawAmount){
	        		System.out.println("Amount deducted from your account with accountId : " + withdrawAccNo);
	        		acc.setBalance(bal-withdrawAmount);
	        		
	        	}
	        }
	        
	        }
		    else{
		    	System.out.println("Account doesn't exist");
		    }
		    

		session.save(acc);
		
        
        Account acc1 = new Account();
		acc1 = session.get(Account.class,withdrawAccNo );
		
		TransactionTable tt = new TransactionTable(TransactionID,acc1.getAccId(),acc1.getAccType(),withdrawAmount,acc1.getCustomer().getCustId());
        
        System.out.println("Transaction successful.");
        
        session.save(tt);
        tx.commit();
		session.close();
    	  
	}
	
	public static void Deposite(int depositeAccNo, int depositeAmount){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		//System.out.println("Hey 1");
	    String TransactionID = "TID" + (int)System.currentTimeMillis() % 100000;
		
        Account acc = new Account();
        
        acc = session.get(Account.class,depositeAccNo);
        //System.out.println("Hey 2");
        
        if(acc != null){
            
            double bal = acc.getBalance();
              
           
                System.out.println("Amount added from your account with accountId : " + depositeAccNo);
                acc.setBalance(bal + depositeAmount);
        		
        }
        else{
        	System.out.println("Something went wrong");
        }

        //tx.commit();
        session.save(acc);
        
       
        
        Account acc1 = new Account();
		acc1 = session.get(Account.class,depositeAccNo );
		
		TransactionTable tt = new TransactionTable(TransactionID,acc1.getAccId(),acc1.getAccType(),depositeAmount,acc1.getCustomer().getCustId());
        
        System.out.println("Transaction successful.");
        
        session.save(tt);
        tx.commit();
        
		session.close();
	}
	
	public static void Transfer(int taccno1, int tamt, int taccno2){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
	
		String TransactionID = "TID" + (int)System.currentTimeMillis() % 100000;
		
		Account acc1 = new Account();
		acc1 = session.get(Account.class, taccno1);
		
		Account acc2 = new Account();
		acc2 = session.get(Account.class, taccno2);
		
        if(acc1 != null){
            
            double bal = acc1.getBalance();
              
           
                System.out.println("Amount deducted from your account with accountId : " + taccno1);
                acc1.setBalance(bal - taccno1);
        		
        }
        else{
        	System.out.println("Invalid input.");
        }
        
        if(acc2 != null){
            
            double bal1 = acc1.getBalance();
              
           
                System.out.println("Amount added to your account with accountId : " + taccno2);
                acc1.setBalance(bal1 + taccno1);
        		
        }
        else{
        	System.out.println("Invalid input.");
        }
        TransactionTable tt = new TransactionTable(TransactionID,acc1.getAccId(),"Transfer",taccno1,acc1.getCustomer().getCustId());
        
		
		session.save(acc1);
		session.save(acc2);
		session.save(tt);
        
       
		
		tx.commit();
		session.close();
	}
	
	public static void closeAccount(int accNumber){
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account acc = new Account();
		acc = session.get(Account.class,accNumber);
		
		HistoryTable ht = new HistoryTable(acc.getAccId(),acc.getAccType(),acc.getBalance(),acc.getCustomer().getCustId());

		System.out.println("Account deleted successfully!");
		session.save(ht);
		session.delete(acc);
		
		tx.commit();
		session.close();
		
	}
	
	public static void printStatement(){
		
	}
	
	public static HashMap<Integer, String > getAllCustomers(){
		HashMap<Integer, String> data = new HashMap<Integer,String>();
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Query query = session.createQuery("FROM Account");
		List<Account> list = query.getResultList();
		
		for (Account acc : list) {
			String name = acc.getCustomer().getName();
			data.put(acc.getAccId(),name);
		}

		session.close();
		return data;
		
		
	}
	
}
