package com.citiustech.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {

	private int cusId;
	private String name;
	private String password;
	private String emailId;
	
	
	public Customer() {
		// TODO Auto-generated constructor stub
		this(0,"","PWD","");
	}


	public Customer(int cusId, String name, String password, String emailId) {
		this.cusId = cusId;
		this.name = name;
		this.password = password;
		this.emailId = emailId;
	}


	@Id
	public int getCusId() {
		return cusId;
	}


	public void setCusId(int cusId) {
		this.cusId = cusId;
	}

	@Column(length = 45, nullable = false)
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	@Column(length = 25, nullable = false)
	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Column(length = 150, nullable = false)
	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	@Override
	public String toString() {
		return "Customer [cusId=" + cusId + ", name=" + name + ", password=" + password + ", emailId=" + emailId + "]";
	}
	
}
