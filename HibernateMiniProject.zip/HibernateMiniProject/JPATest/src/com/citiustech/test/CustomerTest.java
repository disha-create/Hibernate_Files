package com.citiustech.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.citiustech.model.Customer;

public class CustomerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaTest");
		EntityManager em = emf.createEntityManager();
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Customer customer = new Customer(101,"Jack","lion","jack@gmail.com");
		
		em.persist(customer);
		
		tx.commit();
		em.close();
		
		System.out.println("Customer saved!");

	}

}
