package banktest;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Counter;
import util.HibernateUtil;

public class Banktest {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Counter cnt = new Counter();
		cnt = session.get(Counter.class, "Account_id");
		cnt.setCurval(1);
		System.out.println(cnt);
	
	
		
		session.close();
		
		
		
		
		
		
	}

}
