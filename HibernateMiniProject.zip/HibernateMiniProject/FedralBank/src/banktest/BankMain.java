package banktest;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

import businesslogic.Banker;
import model.Account;
import model.Counter;
import model.Customer;
import util.HibernateUtil;



public class BankMain {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
//		Session session = HibernateUtil.getSessionFactory().openSession();
//		
//		Transaction tx = session.beginTransaction();
//		
//		Counter count = new Counter("Account_id",1);
//	
//		session.persist(count);
//		
//		
//		tx.commit();
//		


//		Criteria crt = session.createCriteria(Counter.class);
//		crt.add(Restrictions.);
//		
//		List<Counter> accounts = crt.list();
//		
//		for (Counter account : accounts) {
//			System.out.println(account);
//		}
//		session.close();
//		Session session = HibernateUtil.getSessionFactory().openSession();
//		  Query query = session.createQuery(" FROM Customer"); 
//		  List<Customer> acntId = query.list();
//	 
//		  for (Customer accId : acntId) {							
//			  System.out.println(accId); 
//			  }
//			
//		  	Customer accid = acntId.get(0);
//		  System.out.println(accid);
		
//		  Query query = session.createQuery("SELECT curval FROM Counter"); 
//		  List<Integer> acntId = query.list();
//		 
//		  for (Integer accId : acntId) {
//			  System.out.println(accId); 
//		  }
		
//		  int accid = acntId.get(0);
//		  System.out.println(accid);
	
//		  Counter count = session.load(Counter.class, "Account_id");
//		  Counter cnt = count.setCurval(acntId.get(0)+1);
//		  session.update(cnt);
		  
//		  session.close();
		
		while(true) {
			System.out.println("-------Welcome to FedralBank-------");
			System.out.println("press 1 for Opening an account");
			System.out.println("press 2 for Withdraw");
			System.out.println("press 3 for Deposit");
			System.out.println("press 4 for PassBook");
			System.out.println("press 5 for ClosingAccount");
			System.out.println("press 6 to exit");	
			System.out.println("Enter your choice");
			Scanner scanner = new Scanner(System.in);
			int choice = scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Please fill The form for opening account");
				System.out.println("Enter Your Name:-");
				String name = scanner.next();
				System.out.println("Enter Your PhoneNumber:-");
				Double phone = scanner.nextDouble();
				System.out.println("Enter Your PancardNumber:-");
				String pancard = scanner.next();
				System.out.println("press 1 for SavingAccount");
				System.out.println("press 2 for CurrentAccount");
				int option = scanner.nextInt();
				if (option == 1)
				{
					System.out.println("Opening SavingAccount");
					Banker.opensavingaccount(name, phone, pancard);
//					Session session = HibernateUtil.getSessionFactory().openSession();
//					Transaction tx = session.beginTransaction();
//					Counter cnt = new Counter();
//					cnt = session.get(Counter.class, "Account_id");
//					int cust_id = 1000 + cnt.getCurval();
//					Customer customer = new Customer(cust_id,name,phone,pancard);
//					Account account = new Account(cust_id,"SA",1000);
//					session.save(account);
//					session.save(customer);
//					cnt.setCurval(cnt.getCurval()+1);	
//					tx.commit();
////					int acc_id = customer.getCust_id();
//					System.out.printf("Hello %s%n ,Your Account Was Created Sucessfully with Account id :- %d%n",customer.getName(),customer.getCust_id());

			
//					Counter count = new Counter();
//					count = session1.get(Counter.class, "Account_id");
//					count.setCurval(curval+1);
////					count.setCurval(acntId.get(0)+1);
//					count.setCtrname("Account_id");
//					session.update(count);
//					session.close();
//					System.out.println("SavingAccount Opened");
				}
				else if(option == 2) 
				{	
					System.out.println("Opening CurrentAccount");
					Banker.opencurrentaccount(name, phone, pancard);
//					System.out.println("CurrentAccount Opened");
//					continue;
				}
				else {
					System.out.println("Please Enter a ValidChoice");
				}
				break;
			case 2:
				System.out.println("Please Enter the detail for Withdrawing Money");
				System.out.println("Enter the AccountId");
				int acc_id = scanner.nextInt();
				System.out.println("Enter the Amount");
				double amount = scanner.nextDouble();
				try {
					Banker.withdraw(acc_id, amount);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println("Please Enter a Valid Account number");
				}
			
				break;
			case 3:
				System.out.println("Please Enter the detail for Deposit Money");
				System.out.println("Enter the AccountId");
				int accid1 = scanner.nextInt();
				System.out.println("Enter the Amount");
				double amnt = scanner.nextDouble();
				try {
					Banker.deposit(accid1, amnt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if (amnt>=50000) {
					System.out.println("Enter the PancardNumber");
					String pan = scanner.next();
				}
			
				
				break;
			case 4:
				System.out.println("press 4 for PassBook");
				
				break;
			case 5:
				System.out.println("press 5 for ClosingAccount");
				
				break;
			case 6:
				System.out.println("press 6 to exit");
				System.exit(0);
				
			default:
				System.out.println("Please enter a valid choice");
				break;
			
			
			
		}
		
		
	
//		if(choice<=6) {
//			
//			
//		}
//		else {
//			System.out.println("Please enter a valid choice");
//			menu();
//		}
//		
	}
	}

	}


