package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;



@Entity

public class Customer {
	
private int cust_id;
private String name;
private double phone_number;
private String pancard;

public Customer(int cust_id ,String name, double phone_number, String pancard) {

	this.cust_id = cust_id;
	this.name = name;
	this.phone_number = phone_number;
	this.pancard = pancard;
}
public Customer() {
	// TODO Auto-generated constructor stub
}
@Id
//@GeneratedValue(strategy = GenerationType.TABLE,generator = "tab")
public int getCust_id() {
	return cust_id;
}
public void setCust_id(int cust_id) {
	this.cust_id = cust_id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getPhone_number() {
	return phone_number;
}
public void setPhone_number(double phone_number) {
	this.phone_number = phone_number;
}
public String getPancard() {
	return pancard;
}
public void setPancard(String pancard) {
	this.pancard = pancard;
}

@Override
public String toString() {
	return "Customer [cust_id=" + cust_id + ", name=" + name + ", phone_number=" + phone_number + ", pancard=" + pancard
			+ "]";
}


}
