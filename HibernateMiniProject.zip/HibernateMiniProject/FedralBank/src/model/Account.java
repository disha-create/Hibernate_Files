package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;

@Entity
//@TableGenerator(name="tab", initialValue=1000, allocationSize=50)
public class Account {
	
	private int accountid;
	private String accounttype;
	private double balance;
	

	public Account(int accountid, String accounttype, double balance) {
		super();
		this.accountid = accountid;
		this.accounttype = accounttype;
		this.balance = balance;
	}
	public Account() {
		// TODO Auto-generated constructor stub
	}
	@Id
//	@GeneratedValue(strategy = GenerationType.TABLE,generator = "tab")
	public int getAccountid() {
		return accountid;
	}
	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountid=" + accountid + ", accounttype=" + accounttype + ", balance=" + balance + "]";
	}
}
