package model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Counter {
	
	private String ctrname;
	private int curval;
	public Counter(){
		
	}
	public Counter(String ctrname, int curval) {
		super();
		this.ctrname = ctrname;
		this.curval = curval;
	}
	@Id
	public String getCtrname() {
		return ctrname;
	}
	public void setCtrname(String ctrname) {
		this.ctrname = ctrname;
	}
	public int getCurval() {
		return curval;
	}
	public void setCurval(int curval) {
		this.curval = curval;
	}
	@Override
	public String toString() {
		return "Counter [ctrname=" + ctrname + ", curval=" + curval + "]";
	}

}
