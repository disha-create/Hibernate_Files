package businesslogic;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Account;
import model.Counter;
import model.Customer;
import util.HibernateUtil;

public class Banker {
	public static void  opensavingaccount(String name,double phone,String pancard){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction tx = session.beginTransaction();
		Counter cnt = new Counter();
		cnt = session.get(Counter.class, "Account_id");
		int cust_id = 1000 + cnt.getCurval();
		Customer customer = new Customer(cust_id,name,phone,pancard);
		Account account = new Account(cust_id,"SA",1000);
		session.save(account);
		session.save(customer);
		cnt.setCurval(cnt.getCurval()+1);	
		tx.commit();
//		int acc_id = customer.getCust_id();
		System.out.printf("Hello %s ,Your Saving Account Was Created Sucessfully with Account id :- %d%n",customer.getName(),customer.getCust_id());

	}
	public static void  opencurrentaccount(String name,double phone,String pancard){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Counter cnt = new Counter();
		cnt = session.get(Counter.class, "Account_id");
		int cust_id = 1000 + cnt.getCurval();
		Customer customer = new Customer(cust_id,name,phone,pancard);
		Account account = new Account(cust_id,"CA",0);
		session.save(account);
		session.save(customer);
		cnt.setCurval(cnt.getCurval()+1);	
		tx.commit();
//		int acc_id = customer.getCust_id();
		System.out.printf("Hello %s ,Your Current Account Was Created Sucessfully with Account id :- %d%n",customer.getName(),customer.getCust_id());

	}
	public static void deposit(int accid, double amount)throws Exception{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Account acc = new Account();
		
		acc = session.get(Account.class, accid);
		if(acc != null){
		String acctype = 	acc.getAccounttype();
		
//		System.out.println(acc.getAccounttype().getClass().getSimpleName());
//		System.out.println(acctype);
			if(acctype.equals("SA")){
//			System.out.println("Inside deposit if");
			SavingAccount.deposit(amount,accid);
			}
			else{
				CurrentAccount.deposit(amount, accid);
//			System.out.println("Inside else");
			
			}
		}
		else{
			throw new InvalidAccountException();
			
		}
//		System.out.println(acc);
//		 double balance = acc.getBalance();
		 
		session.close();
		
	}
	public static void withdraw(int accid, double amount)throws Exception{
		Session session = HibernateUtil.getSessionFactory().openSession();
	
		Account acc = new Account();
		acc = session.get(Account.class, accid);
		if(acc != null){
		String acctype = 	acc.getAccounttype();
		
//		System.out.println(acc.getAccounttype().getClass().getSimpleName());
//		System.out.println(acctype);
			if(acctype.equals("SA")){
//			System.out.println("Inside deposit if");
			SavingAccount.withdraw(amount,accid);
			}
			else{
				CurrentAccount.withdraw(amount, accid);
//			System.out.println("Inside else");
			
			}
		}
		else{
			throw new InvalidAccountException();
			
		}
//		System.out.println(acc);
//		 double balance = acc.getBalance();
		 
		session.close();
		
	}
}
