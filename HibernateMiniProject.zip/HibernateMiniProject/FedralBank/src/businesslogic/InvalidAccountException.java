package businesslogic;

public class InvalidAccountException extends Exception {

}
