package businesslogic;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Account;
import util.HibernateUtil;

public class SavingAccount {
public static double min_balance = 500;
public static void deposit(double amount,int accid) {
	// TODO Auto-generated method stub
//	balance += amount;
//	System.out.println("Inside deposit");
	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction tx = session.beginTransaction();
	Account acc = new Account();
	acc = session.get(Account.class, accid);
	acc.setBalance(acc.getBalance()+amount);
	System.out.printf("Sucessfully Deposited Rs %.2f in Account Number %d and your Total Balance is %.2f%n",amount,accid,acc.getBalance());
	tx.commit();
	session.close();
}
public static void withdraw(double amount,int accid) {
	// TODO Auto-generated method stub
//	balance -= amount;
//	System.out.println("Inside deposit");
	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction tx = session.beginTransaction();
	Account acc = new Account();
	acc = session.get(Account.class, accid);
	if((acc.getBalance()-amount)<min_balance){
		System.out.printf("Insufficient Fund in your Account the withdrawable limit is %.2f%n ",acc.getBalance()-min_balance);
	}
	else{
		acc.setBalance(acc.getBalance()-amount);
		System.out.printf("Sucessfully Withdrawn Rs %.2f from Account Number %d and your Total Balance is %.2f%n",amount,accid,acc.getBalance());
	}
//	System.out.printf("Sucessfully Withdrawn Rs %.2f in Account Number %d and your Total Balance is %.2f%n",amount,accid,acc.getBalance());
	tx.commit();
	session.close();
}

}
