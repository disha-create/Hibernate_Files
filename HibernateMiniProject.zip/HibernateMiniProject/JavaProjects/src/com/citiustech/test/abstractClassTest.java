package com.citiustech.test;

import com.citiustech.model.A;

public class abstractClassTest {
	
	public static void main(String[] args){
		
		A a = new A();
		a.greet();

		
		A myA = new A();
		myA.greet2();
		
	}
	
	

	

}
