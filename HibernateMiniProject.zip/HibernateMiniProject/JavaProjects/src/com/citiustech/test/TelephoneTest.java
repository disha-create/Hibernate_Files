package com.citiustech.test;

import com.citiustech.model.SmartTelephone;

public class TelephoneTest {
	public static void main(String[] args){
		
		SmartTelephone sp = new SmartTelephone();
		sp.ring();
		
		
		
		
	}
	
	

}
