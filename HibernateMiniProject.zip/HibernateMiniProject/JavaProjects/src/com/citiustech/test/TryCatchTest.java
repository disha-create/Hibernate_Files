package com.citiustech.test;

import com.citiustech.model.TryCatch;

public class TryCatchTest {

	
	public static void main(String[] args){
		
		TryCatch tc = new TryCatch();
		System.out.println(tc.divide());
		
	}
}
