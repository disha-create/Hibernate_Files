package com.citiustech.model;

interface SampleInterface{
	void method1();
	void method2();
	default void method(){
		System.out.println("default method");
	}
}

interface ChildSampleInterface extends SampleInterface {
	void method3();
	void method4();
	
}


class MyClass implements ChildSampleInterface{
	
	public void method1(){
		System.out.println("Hii");
	}
	public void method2(){
		System.out.println("Hiihello");
	}
	public void method3(){
		System.out.println("hello");
	}
	public void method4(){
		System.out.println("Hey");
	}
}
public class InheritanceInInterfaces {
	
	public static void main(String[] args){
		MyClass c = new MyClass();
		c.method1();
		c.method();
	}
}
