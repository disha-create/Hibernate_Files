package com.citiustech.model;

interface GPS {
	void Findlocation();
	void ShowLocation();
}


interface Camera{

	void TakeSnap();
	void RecordVideo();
	
}



public abstract class Telephone {
	
	abstract void ring(); 
	abstract void lift();
	abstract void disconnect();

}
