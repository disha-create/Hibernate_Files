package com.citiustech.model;

public class TryCatch {
	public int divide(){
		
		int a = 10;
		int b = 0;
		int ans = 0;
		
		int arr[] = {3,45,6,7,8};
		
		try {
			
			ans = a/b;
			System.out.println("Array : "+arr[23]);
			
		}
		catch(ArithmeticException ae){
			System.out.println(ae);
			
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println(e);
			
		}
		catch(Exception e){
			System.out.println("Something is wrong");
			
		}
		
		return ans;
	}
	
		
	

}
