package com.citiustech.model;



abstract class Pen {
	
	
		abstract void write();
		abstract void refill();

}







