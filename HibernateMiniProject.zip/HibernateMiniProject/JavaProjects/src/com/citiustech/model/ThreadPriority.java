package com.citiustech.model;



class MyProrityThreads extends Thread{
	
	public void MyProrityThreads(String string){
		
		int i =0;
		while(i<40000){
			System.out.println("This is : "+string);
		}
		
	}
	
	
	public void run(String s){
		int i = 0;
		while(i<1000){
		System.out.println("Thread1 running...."+s);
		i++;
	}
	}
//	public void run(){
//		System.out.println("Thread1");
//	}
}


public class ThreadPriority {
	public static void main(String[] args){
		
		//Thread t1 = new Thread("Thread1 (Least imp)");
//		Thread t2 = new Thread("Thread2");
//		Thread t3 = new Thread("Thread3");
//		Thread t4 = new Thread("Thread4");
//		Thread t5 = new Thread("Thread5 (Most Important)");
		
		System.out.println("hiii...");
		
		MyProrityThreads t1 = new MyProrityThreads();
		MyProrityThreads t2 = new MyProrityThreads();
		MyProrityThreads t3 = new MyProrityThreads();
		MyProrityThreads t4 = new MyProrityThreads();
		MyProrityThreads t5 = new MyProrityThreads();
		
		t1.setPriority(Thread.MIN_PRIORITY);
		t5.setPriority(Thread.MAX_PRIORITY);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();

		
	}

}
