package com.citiustech.model;

public class BallPen extends Pen {

	public void write(){
		System.out.println("I am writing");
	}
	
	public void refill(){
		System.out.println("Refilling...!");
	}
	
}
