package com.citiustech.model;

public class A extends abstractClass{
	
	@Override
	 public void greet(){
		 System.out.println("Good morning");
	 }
	
	 @Override
	 public void greet2(){
		 System.out.println("Good afternoon");
	 }

}
