package com.citiustech.model;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.util.HibernateUtil;

public class Banker {
	
	public static void createCustomer(String name, int age, String address){
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		int custId = (int) System.currentTimeMillis() % 100000;
		
		Customer customer = new Customer(custId, name, age, address);
		session.persist(customer);
		
		tx.commit();
		session.close();
		
		System.out.println("Your Customer Id: "+custId);
		
	}
	
	public static void openSavingAccount(int custId){
		int accId = (int) System.currentTimeMillis() % 10000;
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account account = new Account(accId, "Saving", 10000, custId);
		session.persist(account);
		
		tx.commit();
		session.close();
		
		System.out.println("Account Created Successfully.....\n Your Account Id: "+accId);
	}
	
	public static void openCurrentAccount(int custId){
		int accId = (int) System.currentTimeMillis() % 10000;
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account account = new Account(accId, "Current", 0, custId);
		session.persist(account);
		
		tx.commit();
		session.close();
		
		System.out.println("Account Created Successfully.....\n Your Account Id: "+accId);
	}
	
	public static void Withdraw(int waccno, int wamt){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
//		Query query = session.createQuery("update account set balance = balance-:balance where accId = :accId");
		Query query = session.createQuery("update "+Account.class.getName()+" set balance = balance-'"+wamt+"' where accId = '"+waccno+"'");
//		query.setParameter("balance", wamt);
//		query.setParameter("accId", waccno);
		
		int update = query.executeUpdate();
		if(update == 1){
			System.out.printf("%d rs is Withdrawn from Account No: %d", wamt, waccno);
		}
		
		tx.commit();
		session.close();
	}
	
	public static void Deposite(int daccno, int damt){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Query query = session.createQuery("update "+Account.class.getName()+" set balance = balance+'"+damt+"' where accId = '"+daccno+"'");
		
		int update = query.executeUpdate();
		if(update == 1){
			System.out.printf("%d rs is Deposited into Account No: %d",damt, daccno);
		}
		
		tx.commit();
		session.close();
	}
	
	public static void Transfer(int taccno1, int tamt, int taccno2){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Query query = session.createQuery("update "+Account.class.getName()+" set balance = balance-'"+tamt+"' where accId = '"+taccno1+"'");
		int update1 = query.executeUpdate();
		
		Query query1 = session.createQuery("update "+Account.class.getName()+" set balance = balance+'"+tamt+"' where accId = '"+taccno2+"'");
		int update2 = query1.executeUpdate();
		
		if(update1==1 && update2==1){
			System.out.printf("%d Amount is Transfered from Account No %d to Account No %d",tamt,taccno1,taccno2);
		}
		
		tx.commit();
		session.close();
	}
	
	public static void closeAccount(){
		
	}
	
	public static void printStatement(){
		
	}
	
}
