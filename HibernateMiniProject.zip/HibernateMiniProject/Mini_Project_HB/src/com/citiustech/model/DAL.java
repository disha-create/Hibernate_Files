package com.citiustech.model;

public class DAL {
	public static void createCustomer(int custId, String name, int age, String address){
		
	}
	
	public static void openSavingAccount(){
		
	}
	
	public static void openCurrentAccount(){
		
	}
	
	public static void Withdraw(){
		
	}
	
	public static void Deposite(){
		
	}
	
	public static void Transfer(){
		
	}
	
	public static void closeAccount(){
		
	}
	
	public static void printStatement(){
		
	}
}
