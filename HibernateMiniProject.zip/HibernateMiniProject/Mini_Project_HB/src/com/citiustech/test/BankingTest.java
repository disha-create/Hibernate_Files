package com.citiustech.test;

import java.util.Scanner;

import com.citiustech.model.Banker;

public class BankingTest {

	public static void main(String[] args) {
		
		while(true){
			
			System.out.println("\n*********************Welcome to Aapna Bank*********************");
			System.out.println("1. Open Account\n2. Withdraw Money\n3. Deposite Money\n4. Transfer Money\n5. Close Account\n6. Print Statement");
			System.out.println("***************************************************************");
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Your Choice: ");
			int choice = sc.nextInt();
			
			switch(choice){
			//opening account
			case 1:
				Scanner sc1 = new Scanner(System.in);
				System.out.println("Enter your name: ");
				String name = sc1.nextLine();
				
				Scanner sc2 = new Scanner(System.in);
				System.out.println("Enter your age: ");
				int age = sc2.nextInt();
				
				Scanner sc3 = new Scanner(System.in);
				System.out.println("Enter your address: ");
				String address = sc3.nextLine();
				
				Banker.createCustomer(name, age, address);
				
				Scanner sc4 = new Scanner(System.in);
				System.out.println("1) Savings Account\n 2) Current Account");
				System.out.println("Select Type of Account: ");
				int accchoice = sc4.nextInt();
				
				switch(accchoice){
				case 1: 
					Scanner sc5 = new Scanner(System.in);
					System.out.println("Enter your customer id: ");
					int custId = sc5.nextInt();
					
					Banker.openSavingAccount(custId);
					break;
					
				case 2:
					Scanner sc6 = new Scanner(System.in);
					System.out.println("Enter your customer id: ");
					int custId1 = sc6.nextInt();
					
					Banker.openCurrentAccount(custId1);
					break;
				}
				break;
				
			//withdraw money
			case 2:
				Scanner sc7 = new Scanner(System.in);
				System.out.println("Enter Account No: ");
				int waccno = sc7.nextInt();
				
				Scanner sc8 = new Scanner(System.in);
				System.out.println("Enter amount to withdraw: ");
				int wamt = sc8.nextInt();
				
				Banker.Withdraw(waccno, wamt);
				break;
				
			//deposite money
			case 3:
				Scanner sc9 = new Scanner(System.in);
				System.out.println("Enter Account No: ");
				int daccno = sc9.nextInt();
				
				Scanner sc10 = new Scanner(System.in);
				System.out.println("Enter amount to deposite: ");
				int damt = sc10.nextInt();
				
				Banker.Deposite(daccno, damt);
				break;
				
			//transfer money
			case 4:
				Scanner sc11 = new Scanner(System.in);
				System.out.println("Enter Your Account No: ");
				int taccno1 = sc11.nextInt();
				
				Scanner sc12 = new Scanner(System.in);
				System.out.println("Enter amount to transfer: ");
				int tamt = sc12.nextInt();
				
				Scanner sc13 = new Scanner(System.in);
				System.out.println("Enter Senders's Account No: ");
				int taccno2 = sc13.nextInt();
				
				Banker.Transfer(taccno1, tamt, taccno2);
				break;
				
			//closing account
			case 5:
				Banker.closeAccount();
				break;
				
			//print statement
			case 6:
				Banker.printStatement();
				break;
				
			default:
				System.out.println("Enter Correct Choice.....");
				break;
			}
			
		}

	}

}
