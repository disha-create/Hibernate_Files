package com.citiustech.model;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.util.HibernateUtil;

public class Banker {
	
	public static void createCustomer(String name, int age, String address, String adharNumber){
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		int custId = (int) System.currentTimeMillis() % 100000;
		
		Customer customer = new Customer(custId, name, age, address, adharNumber);
		session.persist(customer);
		
		tx.commit();
		session.close();
		
		System.out.println("Your Customer Id: "+custId);
		
	}
	
	public static void openSavingAccount(int custId){
		int accId = (int) System.currentTimeMillis() % 10000;
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account account1 = new Account(accId, "Savings", 10000, custId);
		session.persist(account1);
		
		tx.commit();
		session.close();
		
		System.out.println("Account Created Successfully.....\n Your Account Id: "+accId);
	}
	
	public static void openCurrentAccount(int custId){
		int accId = (int) System.currentTimeMillis() % 10000;
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account account = new Account(accId, "Current", 0, custId);
		session.persist(account);
		
		tx.commit();
		session.close();
		
		System.out.println("Account Created Successfully.....\n Your Account Id: "+accId);
	}
	
	public static void Withdraw(int withdrawAccNo, int withdrawAmount){
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account acc = new Account();
		acc = session.get(Account.class, withdrawAccNo );
		if(acc != null){
	        String acctype = acc.getAccType();
//	        int n= 10;
//	        if(acctype == ("Savings"){
//	        	n=1;	
//	        }
//	        if else(acctype == ("Savings")
	        if(acctype == "Savings"){
	        	double bal = acc.getBalance();
	        	if(bal >= 10000+withdrawAmount){
	        		System.out.println("Amount deducted from your account with accountId : " + withdrawAccNo);
	        		acc.setBalance(bal-withdrawAmount);
	        		
	        	}
	        }
	        
	        
	        if(acctype == ("Current")){
	        	double bal = acc.getBalance();
	        	if(bal >= withdrawAmount){
	        		System.out.println("Amount deducted from your account with accountId : " + withdrawAccNo);
	        		acc.setBalance(bal-withdrawAmount);
	        		
	        	}
	        }
	        else {
//	        	throw new InvalidAccountException();
	        	System.out.println("Something went wrong...");
	        }
	        
		}
		
		else{
			System.out.println("Account doesn't exist");
		}
	        
		
	    
		tx.commit();
		session.close();
		
		
		Session session1 = HibernateUtil.getSessionFactory().openSession();
		Account acc1 = new Account();
		acc1 = session.get(Account.class, withdrawAccNo );
        Transaction tx1 = session.beginTransaction();
        
        TransactionTable tt = new TransactionTable();
        tt.setAccId(acc1.getAccId());
        tt.setAccType(acc1.getAccType());
        tt.setBalance(acc1.getBalance());
        tt.setCustId(acc1.getCustId());
        
        tx1.commit();
    	session1.close();
		
	}
	
	
	public static void Deposite(int depositeAccNo, int depositeAmount){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
        Account acc = new Account();
        
        acc = session.get(Account.class,depositeAccNo);
        
        if(acc != null){
            
            double bal = acc.getBalance();
              
           
                System.out.println("Amount added from your account with accountId : " + depositeAccNo);
                acc.setBalance(bal+depositeAmount);
                
                tx.commit();
                
                Account acc1 = new Account();
        		acc1 = session.get(Account.class,depositeAccNo );
        		int custId1= acc1.getCustId();
        		int accId1=acc1.getAccId();
        		String accType1= acc1.getAccType();
        		double balance1 = acc1.getBalance();
                Transaction tx1 = session.beginTransaction();
                
                TransactionTable tt = new TransactionTable(accId1,accType1,balance1,custId1);
                System.out.println("Transaction successful.");
                tx1.commit();
        }
        else{
        	System.out.println("Something went wrong");
        }
        
		session.close();
		
    	
	}
	
	public static void Transfer(int taccno1, int tamt, int taccno2){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Query query = session.createQuery("update "+Account.class.getName()+" set balance = balance-'"+tamt+"' where accId = '"+taccno1+"'");
		int update1 = query.executeUpdate();
		
		Query query1 = session.createQuery("update "+Account.class.getName()+" set balance = balance+'"+tamt+"' where accId = '"+taccno2+"'");
		int update2 = query1.executeUpdate();
		
		if(update1==1 && update2==1){
			System.out.printf("%d Amount is Transfered from Account No %d to Account No %d",tamt,taccno1,taccno2);
		}
		
		tx.commit();
		session.close();
	}
	
	public static void closeAccount(int accNumber){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Account acc = new Account();
		acc = session.get(Account.class,accNumber);
		
        Transaction tx1 = session.beginTransaction();
		
		HistoryTable ht = new HistoryTable();
		ht.setAccId(acc.getAccId());
		ht.setAccType(acc.getAccType());
		ht.setBalance(acc.getBalance());
		ht.setCustId(acc.getCustId());
		
		tx1.commit();
		
		session.delete(acc);
		System.out.println("Your account is deleted.");
		
		
		tx.commit();
		
		
		session.close();
		
		
	}
	
	public static void printStatement(){
		
	}
	
}
