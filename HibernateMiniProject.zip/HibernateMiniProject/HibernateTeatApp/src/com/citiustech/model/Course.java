package com.citiustech.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Course {

	private int cid;
	private String name;
	
	
	public Course() {
		this(12,"Java");
		// TODO Auto-generated constructor stub
	}

	public Course(int cid, String name) {
		this.cid = cid;
		this.name = name;
	}
	
	@Id
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	private Set<Student> students;

	@OneToMany
	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	@Override
	public String toString() {
		return "Course [cid=" + cid + ", name=" + name + ", students=" + students + "]";
	}
	

	
}
