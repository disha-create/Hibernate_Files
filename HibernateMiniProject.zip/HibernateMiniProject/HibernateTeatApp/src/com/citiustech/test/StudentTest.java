package com.citiustech.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.model.Student;
import com.citiustech.util.HibernateUtil;

public class StudentTest {
	
	public static void main(String[] args){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction tx = session.beginTransaction();
		
		Student student = new Student();
		student.setId(11);
		student.setName("Jack");
		student.setAge(23);
		student.setAddress("Mumbai");
		
		session.persist(student);
		
		tx.commit();
		session.close();
		
		System.out.println("Student saved");
	}

}
