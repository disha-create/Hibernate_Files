package com.citiustech.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.model.Department;
import com.citiustech.model.Employee;
import com.citiustech.util.HibernateUtil;

public class EmployeeDepartmentPayrollTest {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		Department sales = new Department(5001, "Sales");
		
		session.save(sales);
		
		Employee jack = new Employee(1001, 180, 100);
		jack.setDepartment(sales);
		session.save(jack);
		
		tx.commit();
		session.close();
		
		System.out.println("Department saved with employee");
	}


}
