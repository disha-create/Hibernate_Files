package com.citiustech.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Subject {
	
	private int subId;
	private String subName;
	
	public Subject() {
		this(11,"Maths");
		// TODO Auto-generated constructor stub
	}
	
	
	public Subject(int subId, String subName) {
		this.subId = subId;
		this.subName = subName;
	}



	@Id
	public int getSubId() {
		return subId;
	}
	public void setSubId(int subId) {
		this.subId = subId;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}
	
	private Set<Professor> professors;

	@ManyToMany(mappedBy="name")
	public Set<Professor> getProfessors() {
		return professors;
	}


	public void setProfessors(Set<Professor> professors) {
		this.professors = professors;
	}
	
	
	


}
