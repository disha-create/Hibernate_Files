package com.citiustech.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Department {
	
	private int deptId;
	private String name;
	
	public Department() {
		this(0,"dept");
		// TODO Auto-generated constructor stub
	}

	public Department(int deptId, String name) {
		this.deptId = deptId;
		this.name = name;
	}
	
	
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	
	@Id
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	private Set<Employee> employees;

	@OneToMany(mappedBy = "department")
	public Set<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
	
	
	

}
