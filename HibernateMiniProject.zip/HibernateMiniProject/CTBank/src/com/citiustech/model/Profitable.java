package com.citiustech.model;

public interface Profitable {

	void addInterest(int period);
	
}
