package com.citiustech.model;

public class InsufficientFundsException extends Exception {

}
