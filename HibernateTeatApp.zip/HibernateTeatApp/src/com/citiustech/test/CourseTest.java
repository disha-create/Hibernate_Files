package com.citiustech.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.model.Course;
import com.citiustech.model.Student;
import com.citiustech.util.HibernateUtil;

public class CourseTest {
	
	public static void main(String[] args){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction tx = session.beginTransaction();
		
		Course course = new Course();
		course.setCid(1);
		course.setName("Java");
		
		session.persist(course);
		
		tx.commit();
		session.close();
		
		System.out.println("Course saved");
	}

}
