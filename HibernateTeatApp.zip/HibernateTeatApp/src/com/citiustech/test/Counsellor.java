package com.citiustech.test;


import java.util.Scanner;

import javax.persistence.Entity;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.model.Course;
import com.citiustech.model.Logic;
import com.citiustech.model.Student;
import com.citiustech.util.HibernateUtil;

@Entity
public class Counsellor {
	

	public static void main(String[] args){
		
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Student Id");
		int sid1 = scanner.nextInt();
		
		System.out.println("Enter student age");
		int age1 = scanner.nextInt();
		
		System.out.println("Enter student name");
		scanner.nextLine();
		String name1 = scanner.nextLine();
		
		System.out.println("Enter student address");
		String address1 = scanner.nextLine();
		
		System.out.println("Enter student course");
		String course1 = scanner.nextLine();
		
		Logic l = new Logic();
		l.RegisterStudent(sid1, age1, name1, address1, course1);
		
	}

}
