package com.citiustech.model;

import javax.persistence.Entity;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.util.HibernateUtil;

@Entity
public class Logic {

	public static void RegisterStudent(int id,int age,String name,String address, String course){
        Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction tx = session.beginTransaction();
		
		int cid = (int)System.currentTimeMillis() % 10000;
		
        Course course1 = new Course(cid,course);
        Student student1 = new Student();
        student1.setId(id);
        student1.setAge(age);
        student1.setName(name);
        student1.setAddress(address);
        student1.setCourses(course1);
        
        session.save(course1);
        session.save(student1);
		 
		tx.commit();
		session.close();

		System.out.println("Student Registered!");
		
	} 
}
