package com.citiustech;




//@Table (name = "Books")

public class Book {
	
	int bookId;
	String bookName;
	String bookAuthorName;
	Double price;
	
	
	
	public Book(int bookId, String bookName, String bookAuthorName, Double price) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookAuthorName = bookAuthorName;
		this.price = price;
	}
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Id
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookAuthorName() {
		return bookAuthorName;
	}
	public void setBookAuthorName(String bookAuthorName) {
		this.bookAuthorName = bookAuthorName;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}

}



