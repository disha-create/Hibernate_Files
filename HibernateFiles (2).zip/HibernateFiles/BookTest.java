package com.citiustech;


public class BookTest {
	
	public static void main(String[] args)
	{
//		
//		Book b = new Book();
//		b.setBookId(101);
//		b.setBookName("Ikigai");
//		b.setBookAuthorName("H�ctor Garc�a");
//		b.setPrice(null);
		
		abstract class A

	    {

	        int i;

	        abstract void display();

	    }   

	    class B extends A

	    {

	        int j;

	        void display()

	        {

	            System.out.println(j);

	        }

	    }   

	    class Abstract_demo

	    {

	        public static void main(String args[])

	        {

	            B obj = new B();

	            obj.j=2;

	            obj.display();   

	        }

	    }
		
		
	}

}
