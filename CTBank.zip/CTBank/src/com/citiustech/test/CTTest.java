package com.citiustech.test;

import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.*;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.citiustech.model.Account;
import com.citiustech.model.Banker;
import com.citiustech.model.Profitable;
import com.citiustech.util.HibernateUtil;

public class CTTest {
	
	private static void payAnnualInterest(Account[] accounts) {
		for (com.citiustech.model.Account account : accounts) {
			if(account instanceof Profitable) {
				Profitable p = (Profitable) account;
				p.addInterest(1);
			}
		}
	}
	
	
	public static void main(String[] args) {
		
	int number;
	Scanner scanner = new Scanner(System.in);
	Map<Account,Integer> acc = new HashMap<Account,Integer>();
	
	
	
    //Creating infinite while loop
    while(true) {
        //Creating menu
    	System.out.println("*************** Welcome to CT Bank *****************");
    	System.out.println("Press the appropriate option from following");
    	System.out.println(" 1 for Open Account");
        System.out.println(" 2 for Withdraw");
        System.out.println(" 3 for Deposit");
        System.out.println(" 4 for Transfer");
        System.out.println(" 5 for Close Account ");
        System.out.println(" 6 for Print Account transaction ");
        System.out.println(" 7 for Quit ");
        System.out.println("*****************************************************");
        //Asking user to make choice
        System.out.println("Make your choice");
        
        number = scanner.nextInt();
        //Creating switch case branch
        
        try{

        	Session session = HibernateUtil.getSessionFactory().openSession();
        	System.out.println("Connection done");
    		
    		Transaction tx = session.beginTransaction();
    		
    		switch(number){
    		case 1:
    			
    		
    		}
    			
    		
    		tx.commit();
    		session.close();

    		System.out.println("Student Registered!");
	    	System.out.println("Connection Done");
	    	
	    	
	    } catch (SQLException e) {
	    	
	    	e.printStackTrace();
	    	
	    }
		


        
    						
    }

}
}
