package com.citiustech.test;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.citiustech.model.Professor;
import com.citiustech.model.Subject;

public class ProffesorSubjectTest {
	
	public static void main(String[] args)
	{

		Configuration cfg = new Configuration().configure();
		SessionFactory factory = cfg.buildSessionFactory();
		
		Subject subject1 = new Subject(11,"Maths");
		Subject subject2 = new Subject(22,"English");
		
		Professor proffesor1 = new Professor(121,"Jill");
		Professor proffesor2 = new Professor(122,"Jack");
		
		Set<Subject> subList = new HashSet<Subject>();
		subList.add(subject1);
		subList.add(subject2);
		
		Set<Professor> professorList = new HashSet<Professor>();
		professorList.add(proffesor1);
		professorList.add(proffesor2);
		
		subject1.setProfessors(professorList);
		subject2.setProfessors(professorList);
		
		proffesor1.setSubjects(subList);
		proffesor2.setSubjects(subList);
		
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(subject1);
		session.save(subject2);
		session.save(proffesor1);
		session.save(proffesor2);
		
		tx.commit();
		session.close();
		System.out.println("Professor saved");
	}


}
