package com.citiustech.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Employee {
	
	private int empId;
	private int hours;
	private float rate;

	
	public Employee() {
		this(0,90,70);
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int empId, int hours, float rate) {
		super();
		this.empId = empId;
		this.hours = hours;
		this.rate = rate;
	}
	
	@Id
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	
	private Department department;

	@ManyToOne
	@JoinColumn(name = "name")
	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

}
