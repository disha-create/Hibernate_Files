package com.citiustech.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Professor {
	
	private int id;
	private String name;
	
	public Professor() {
		this(1, "John");
		// TODO Auto-generated constructor stub
	}

	public Professor(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	private Set<Subject> subjects;

	@ManyToMany
	public Set<Subject> getSubjects() {
		return subjects;
	}

	public void setSubjects(Set<Subject> subjects) {
		this.subjects = subjects;
	}

}
